document.addEventListener('mousemove',coffee_move);
function coffee_move(event)
{
     this.querySelectorAll('.coffee_move').forEach(layer=>{
        const speed=layer.getAttribute('data-speed')
        const x=(window.innerWidth-event.pageX*speed)/120
        const y=(window.innerWidth-event.pageY*speed)/120
        layer.style.transform=`translateX(${x}px) translateY(${y}px)`
     })
}
